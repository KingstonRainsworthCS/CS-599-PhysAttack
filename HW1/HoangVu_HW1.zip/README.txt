First run:
python3 -m pip install -r ./requirements.txt
Then run:
python3 IA2.py
